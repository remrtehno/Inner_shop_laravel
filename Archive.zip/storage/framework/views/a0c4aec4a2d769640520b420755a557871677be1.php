



<?php $__env->startSection('content'); ?>

    <main>
        <section class="product-details-page" style="padding-top: 100px;">

            <div>
                <div class="section-product-details beauty-wrapper">
                    <div class="row">
                        <div class="small-12 medium-5 columns">
                            <div class="image-container">
                                <div class="product-image-carousel">
                                    <div class="slick-slider">
                                        <div class="image">

                                            <img src="<?php echo e($product->getImageHome()); ?>" width="400" height="400" alt="">
                                        </div><!-- /.image 400x400 -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="small-12 medium-7 columns">
                            <div class="product-detail animated fadeInUp normal"
                                 data-animation="animated fadeInUp normal">
                                <h2 class="title"> <?php echo e($product->article); ?>

                                    <div class="share-box"><a class="share-link-button"><i
                                                    class="link-share fa fa-share-square-o"></i></a>

                                    </div>
                                </h2>
                                <p>В наличии <?php echo e($product->qty ? $product->qty : '0'); ?> </p>
                                <div class="product__price">
                                    <?php if($product->label): ?>
                                        <div style="display: inline-block; background: red; font-size: 16px; color: white; padding: 5px 10px;
                                              "> Скидка <?php echo e($product->label); ?> %
                                        </div>
                                    <?php endif; ?>
                                    <p></p>
                                    <strong>
                                        <?php echo e($product->price); ?> <span>сум.</span>
                                    </strong> <span class="small__text">за<!-- --> 1<!-- -->шт </span></div>

                                <div class="row">
                                    <div class="small-12 medium-12 columns main-buttons">
                                        <div class="clearfix">
                                            <div class="add-cart horizontal cart-41908                              wide-box not-added">
                                                <a href="<?php echo e(route('add', [ 'id' => $product->id ])); ?>">
                                                    <!-- The button for adding the product to the cart -->
                                                    <button <?php if(!$product->qty): ?> disabled
                                                            <?php endif; ?> class="button expanded add-to-cart"><span
                                                                class="gl-shopping-cart"></span> <!-- -->Заказать
                                                    </button>
                                                </a>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="row hide-for-small-only" style="overflow-x:hidden">
                                    <div class="small-12 medium-12 xlarge-12 columns"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </main>





<?php $__env->stopSection(); ?>


<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/products/detail.blade.php ENDPATH**/ ?>