<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Samples extends Model
{
    //
		 protected  $table = "samples";
	  protected $fillable = ['shop_id','product_id',];
}
