<?php $__env->startSection("content"); ?>

<style>
  .badge {
    background: red;
  }
</style>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">


            <h1>
               Магазины
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">Blank page</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
                <div class="form-group">
                        <a href="<?php echo e(route('shops.create')); ?>" class="btn btn-success">Добавить</a>
                    </div>
            <div>
                


              <!-- Nav tabs -->
              <ul class="nav nav-tabs" role="tablist">
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li role="presentation" class="<?php echo e($key == 0 ? 'active' : ''); ?>"><a href="#m-<?php echo e($item->id); ?>" aria-controls="home" role="tab" data-toggle="tab"> <?php echo e($item->title); ?> 
                     <?php if(count($item->ordersWait())): ?> <span class="badge" > <?php echo e(count($item->ordersWait())); ?></span> <?php endif; ?>
  </a></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li role="presentation"><a href="#returned" aria-controls="returned" role="tab" data-toggle="tab"> 
                    Возвращенные товары
                  </a>
                </li>
              </ul>

              <!-- Tab panes -->
              <div class="tab-content">
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div role="tabpanel" class="tab-pane <?php echo e($key == 0 ? 'active' : ''); ?>" id="m-<?php echo e($item->id); ?>">
                      <?php if(count($item->orders())): ?>

                          <table class="table table-bordered table-striped DataTable">
                       <thead>
                         <tr>
                            <th>Date</th>
                            <th>ID заказа</th>
                            <th>Артикул</th>
                            <th>Партия</th>
                            <th>Склад</th>
                            <th>Цена за шт.</th>
                            <th>Количество</th>
                            <th>Общая Цена</th>

                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                       </thead>
                      

                        
                        <?php $__currentLoopData = $item->orders(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr style=" ">
                            <td><?php echo e($val->created_at); ?></td>
                            <td><?php echo e($val->id); ?></td>
                            <td><?php echo e($val->article); ?></td>
                            <td><?php echo e($val->batch); ?></td>
                            <td><?php echo e($val->sklad); ?></td>
                            <td><?php echo e($val->tovar_price); ?></td>
                            <td><?php echo e($val->qty); ?></td>
                            <td><?php echo e($val->tovar_price * $val->qty); ?></td>
                            <td><?php echo e($val->getStatus()); ?></td>




                            <td>
                              <a style="float: left;"  class="btn btn-success" href="<?php echo e(route('cahngeStatus', ['id' => $val->id])); ?>">Отпустить товар</a>
                             
                            <button type="submit" class="btn btn-primary return-product">Вернуть товар</button> 

                            <div class="modal-returned" style="display: none; width: 400px;">
                              <form action="<?php echo e(route('returnProduct')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="POST">
                                <input type="hidden" name="id" value="<?php echo e($val->id); ?>">
                                <textarea class="noEditor" name="is_text" style="width: 100%;" rows="4"><?php echo $val->is_text; ?></textarea><!-- /# -->
                                <br>
                                <button type="submit">Сохранить</button>
                              </form>
                            </div>
                             
                             <!-- <form style="float: left;" action="<?php echo e(route('cahngeStatus',['id'=>$item->id, 'status' => 'Возврат'])); ?>" method="post">
                                    <?php echo csrf_field(); ?>

                                    
                                    <input type="hidden" name="_method" value="put">

                                    
                                </form> -->

                              <!-- <form style="float: left;" action="<?php echo e(route('cahngeStatus',['id'=>$item->id, 'status' => 'Нету на складе'])); ?>" method="post">
                                    <?php echo csrf_field(); ?>


                                    <button type="submit" class="btn btn-danger">Нету на складе</button>
                                    <input type="hidden" name="_method" value="put">

                                    
                                </form> -->

                              
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      

                      </table>
                        <?php else: ?>
                          <td colspan="5"><h3 align="center">Заказов нету</h3></td>
                        <?php endif; ?>
                      
                      <a class=" btn btn-info" href="<?php echo e(route('shops.edit',['id'=>$item->id])); ?>">Редактировать <i class="fa fa-pencil"></i></a>


                      <hr>

                      
                    <!--   <br>
                      Оплата:   0<br> 
                      <select name="" id="">
                        <option value=""></option>
                      </select>
                      <button></button> -->

                     <!--  <span style="background: red;">Остаток:   0<br></span> -->



                      <hr>

                     
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 <div role="tabpanel" class="tab-pane" id="returned">
                  <table class="table table-bordered table-striped DataTable">
                     <thead>
                    <tr>
                      <td>Магазин</td>
                      <td>Продукт</td>
                      <td>Примечание</td>
                      <td>Количестов</td>
                      <td>Дата</td>
                      <td>Действия</td>
                    </tr>
                  </thead>
                  
                  <?php $__currentLoopData = $returned_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($item->shop_id); ?></td>
                      <td><?php echo e($item->product_id); ?></td>
                      <td><?php echo e($item->text); ?></td>
                      <td><?php echo e($item->qty); ?></td>
                      <td><?php echo e($item->created_at); ?></td>
                      <td>
                        <a style="float: left;"  class="btn btn-success" href="<?php echo e(route('returnSupplier', ['id' => $item->product_id, 'qty' => $item->qty])); ?>">Вернуть поставщику</a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                 </div>

                
                 
              </div>

            </div>


        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->


    <script>


  var int = setInterval(function(){ 
    window.location.reload();
   }, 20000);


window.onbeforeunload = function() {
  clearInterval(int);
}


  window.onload = function() {


    var audioElement = document.createElement('audio');
        audioElement.setAttribute('src', '/assets/exclamation.mp3');
        audioElement.setAttribute('preload', 'auto');
        //audioElement.setAttribute('onended', 'window.location.reload()');


    function playAudio() {
        audioElement.load;
        audioElement.play();
    };

    if(document.querySelector('.nav-tabs .badge')) {

      playAudio();
    }

  };


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/admin/shops/index.blade.php ENDPATH**/ ?>