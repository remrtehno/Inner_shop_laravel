<ul class="sidebar-menu">
    <li class="header">MAIN NAVIGATION</li>

<!--  <li><a href="<?php echo e(route('post.index')); ?>"><i class="fa fa-sticky-note-o"></i> <span>Продукция</span></a></li>
    <li><a href="<?php echo e(route('category.index')); ?>"><i class="fa fa-list-ul"></i> <span>Категории</span></a></li>
    <li><a href="<?php echo e(route('slider.index')); ?>"><i class="fa fa-tags"></i> <span>Слайдер</span></a></li>
    <li><a href="<?php echo e(route('gallery.index')); ?>"><i class="fa fa-tags"></i> <span>Галлерея</span></a></li>
    <li><a href="<?php echo e(route('video.index')); ?>"><i class="fa fa-tags"></i> <span>Видео</span></a></li>
    <li><a href="<?php echo e(route('logo.index')); ?>"><i class="fa fa-tags"></i> <span>Логотип</span></a></li>

    <li><a href="<?php echo e(route('about.index')); ?>"><i class="fa fa-users"></i> <span>О нас</span></a></li>
    <li><a href="<?php echo e(route('contact.index')); ?>"><i class="fa fa-users"></i> <span>Контакты</span></a></li>
    <li><a href="<?php echo e(route('news.index')); ?>"><i class="fa fa-user-plus"></i> <span>Новости</span></a></li> -->

    <li><a href="<?php echo e(route('post.index')); ?>"><i class="fa fa-tags"></i> <span>Все товары</span></a></li>
    <li><a href="<?php echo e(route('shops.index')); ?>"><i class="fa fa-tags"></i> <span>Магазины</span></a></li>
    <li><a href="<?php echo e(route('orders.index')); ?>"><i class="fa fa-tags"></i> <span>Заказы</span></a></li>
    <li><a href="<?php echo e(route('payments-shop.index')); ?>"><i class="fa fa-tags"></i> <span>Оплата - Магазины</span></a></li>
    <li><a href="<?php echo e(route('payments-supplier.index')); ?>"><i class="fa fa-tags"></i> <span>Оплата - Поставщики</span></a>
    </li>
    <li><a href="<?php echo e(route('suppliers.index')); ?>"><i class="fa fa-tags"></i> <span>Поставщики</span></a></li>
    <li><a href="<?php echo e(route('news.index')); ?>"><i class="fa fa-tags"></i> <span>Пользователи</span></a></li>
    <li><a href="<?php echo e(route('samples.index')); ?>"><i class="fa fa-tags"></i> <span>Образцы</span></a></li>
    <li><a href="<?php echo e(route('warehouse.index')); ?>"><i class="fa fa-tags"></i> <span>Склады</span></a></li>
<!--  <li><a href="<?php echo e(route('shops.show', Auth::user()->id )); ?>"><i class="fa fa-user"></i> <span>Мой магазин</span></a></li> -->
    <li><a href="<?php echo e(route('statisics.index')); ?>"><i class="fa fa-tags"></i> <span>Статистика</span></a></li>
</ul><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/admin/lib/left.blade.php ENDPATH**/ ?>