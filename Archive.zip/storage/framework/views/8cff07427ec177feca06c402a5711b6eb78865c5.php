

<div class="cabinet-menu">
        <div class="">
            <ul class="menu vertical no-bullet">
                <li> <a class="icon wishlist" aria-current="false" href="cabinet-favorit.html"> Избранное </a> </li>
                <li> <a class="icon shops" aria-current="false" href="cabinet-shops.html"> Магазины </a> </li>
                <li> <a class="icon bills" aria-current="false" href="cabinet-bills.html"> Счет </a> </li>
                <li> <a class="icon watchlist" aria-current="false" href="/user/watchlist"> Просмотренные </a> </li>
                <li class="magazine_act"> <a class="icon open-shops" aria-current="false" href="cabine-create-shop.html"> Открыть магазин </a> </li>
            </ul>
        </div>
    </div>
<?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/lib/cabinet-menu.blade.php ENDPATH**/ ?>