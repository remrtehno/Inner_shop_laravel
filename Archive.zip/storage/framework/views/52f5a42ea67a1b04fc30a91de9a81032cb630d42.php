<?php $__env->startSection("content"); ?>

    <style>
        .badge {
            background: red;
        }
    </style>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Магазины
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">Blank page</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <div>


                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li role="presentation" class="<?php echo e($key == 0 ? 'active' : ''); ?>"><a href="#m-<?php echo e($item->id); ?>"
                                                                                          aria-controls="home"
                                                                                          role="tab"
                                                                                          data-toggle="tab"> <?php echo e($item->title); ?>


                            </a></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">

                    <div class="box" style="padding: 20px 20px; padding-bottom: 10px; margin: 0; margin-top: 15px;">


                        <form action="<?php echo e(route('statisics.index')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="to" value="" placeholder="до" style="float: right;">
                            <input type="hidden" name="from" value="">

                            <button style="float: right;">Сбросить фильтр</button>


                        </form>


                        <form action="<?php echo e(route('statisics.index')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <h4 align="center" style="float: left;">Выберите дату</h4>
                            <button style="float: right;">Показать</button>

                            <input class="datapicker" data-date-format="mm/dd/yyyy" name="to" value="<?php echo e($to); ?>"
                                   placeholder="до" style="float: right;">
                            <input class="datapicker" data-date-format="yyyy-mm-dd " name="from" value="<?php echo e($from); ?>"
                                   placeholder="от" style="float: right;">
                            <div style="clear: both;"></div>
                        </form>

                    </div>






                    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                        <div role="tabpanel" class="tab-pane <?php echo e($key == 0 ? 'active' : ''); ?>" id="m-<?php echo e($item->id); ?>">
                            <br>
                            <p></p>
                            <table class="table" style="padding-top: 20px">
                                <thead>
                                    <tr>
                                        <th>Склад</th>
                                        <th>Количество</th>
                                        <th>Закупочная Цена</th>
                                    </tr>
                                </thead>
                                <?php if(count($item->statistics_warehouse())): ?>

                                    <?php $sum = 0; $cnt = 0; ?>
                                <?php $__currentLoopData = $item->statistics_warehouse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                    <?php $sum += $val->sum; $cnt += $val->cnt; ?>
                                    <tr>
                                        <td><?php echo $val->sklad; ?></td>
                                        <td><?php echo $val->cnt; ?></td>
                                        <td><?php echo $val->sum ? $val->sum : 0; ?>$</td>
                                    </tr>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <tr style="font-weight: bold;">
                                        <td>Всего</td>
                                        <td><?php echo e($cnt); ?></td>
                                        <td><?php echo e($sum); ?>$</td>
                                    </tr>

                                <?php endif; ?>

                            </table>



                            <?php if(count($item->statistics($from, $to))): ?>
                                <br>


                                <div class="clearfix"></div>


                                <div class="box">


                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Дата</th>
                                            <th>Количество</th>
                                            <th>Цена</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $item->statisticsByDate($from, $to); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <b> <?php if($from || $to): ?>
                                                            <?php echo e($from ? 'от' : ''); ?> <?php echo e($from); ?> <?php echo e($to ? 'до' : ''); ?> <?php echo e($to); ?>

                                                        <?php else: ?>
                                                            За сегодня
                                                        <?php endif; ?>
                                                    </b>
                                                </td>
                                                <td>
                                                    <?php echo e($val->cnt); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($val->price ? $val->price : '0'); ?> сум
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $item->statistics(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <b> Общее за все время</b>
                                                </td>
                                                <td>
                                                    <?php echo e($val->cnt); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($val->price ? $val->price : '0'); ?> сум
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div><!-- /.box -->




                            <?php else: ?>
                                <td colspan="5"><h3 align="center">Пусто</h3></td>
                            <?php endif; ?>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

            </div>


        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/admin/statistics/index.blade.php ENDPATH**/ ?>