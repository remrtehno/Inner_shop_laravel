<?php $__env->startSection("content"); ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
               Магазины
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">Blank page</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <div>

              <!-- Nav tabs -->
              <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#m1" aria-controls="home" role="tab" data-toggle="tab">Магазин 1 <span class="badge">3</span></a></li>
              </ul>

              <!-- Tab panes -->
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="m1">...</div>
                <div role="tabpanel" class="tab-pane active" id="m2">...</div>
                <div role="tabpanel" class="tab-pane active" id="m3">...</div>
                <div role="tabpanel" class="tab-pane active" id="m4">...</div>
                <div role="tabpanel" class="tab-pane active" id="m5">...</div>
                <div role="tabpanel" class="tab-pane active" id="m6">...</div>
              </div>

            </div>


        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/admin/shops/add.blade.php ENDPATH**/ ?>