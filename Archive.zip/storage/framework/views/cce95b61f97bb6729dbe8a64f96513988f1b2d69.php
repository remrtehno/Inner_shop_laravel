









<?php $__env->startSection('content'); ?>

<section class="user-cabinet beauty-wrapper">
            <div class="row">
                <div class="small-12 medium-12 columns">
                    <h1 class="title hide-for-small-only hide-for-medium-only hide-for-large-only"> Мой профиль </h1>
                </div>
                <div class="small-12 medium-3 columns">
                    
                    <?php echo $__env->make('lib.cabinet-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                </div>
                <div class="small-12 medium-9 columns details">
                    <div class="latest-orders cabinet-block">
                        <h4 class="widget-title">Добро пожаловать</h4>
                        <h6>Начало работы</h6>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <div class="footer-bar"> ® copyright 2020. | Разработано в <a href="http://steepcoder.uz/site">steepcoder.uz</a> </div> <!-- /.footer-bar -->
        </footer>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footerinput'); ?>
    <?php echo $__env->make("lib.footerinput", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/index/index.blade.php ENDPATH**/ ?>