<?php $__env->startSection('content'); ?>

    <section class="user-cabinet beauty-wrapper">
        <div class="row">
            <div class="small-12 medium-12 columns">
                <h1 class="title hide-for-small-only hide-for-medium-only hide-for-large-only"> Мой профиль </h1>
            </div>
            <div class="small-12 medium-3 columns">

                <?php echo $__env->make('lib.cabinet-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            </div>
            <div class="small-12 medium-9 columns details">
                <div class="latest-orders cabinet-block">
                    <h4 class="widget-title">Заказы</h4>
                    <div class="score_main">
                        <table class="score table">
                            <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>Артикул</th>
                                    <th>Партия</th>
                                    <th>Количество</th>
                                    <th>Розничная Цена</th>
                                    <th>Статус</th>
                                    <th>Комментарий</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <?php if($orders->count() > 0): ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td><?php echo e($item->article); ?></td>
                                        <td><?php echo e($item->batch); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e($item->tovar_price); ?></td>
                                        <td><?php echo e($item->getStatus()); ?></td>
                                        <td><?php echo e($item->is_text); ?></td>
                                        <td>
                                            <a class="btn btn-danger" href="<?php echo e(route('return-order', ['id' => $item->id])); ?>">Возврат</a>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </table>
                        <?php else: ?>
                            Пусто
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="footer-bar"> ® copyright 2020. | Разработано в <a href="http://steepcoder.uz/site">steepcoder.uz</a>
        </div> <!-- /.footer-bar -->
    </footer>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footerinput'); ?>
    <?php echo $__env->make("lib.footerinput", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/orders/index.blade.php ENDPATH**/ ?>