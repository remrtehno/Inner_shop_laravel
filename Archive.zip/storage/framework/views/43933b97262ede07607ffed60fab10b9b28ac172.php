

<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Изменить Статью
                <small>приятные слова..</small>
            </h1>
        </section>

        <!-- Main content -->
        <section class="content">
        <?php echo $__env->make('admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Default box -->

            <form action="<?php echo e(route('payments-supplier.update',['id'=>$sl->id])); ?>" method="post" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Обновляем Статью</h3>
                    </div>



                    <div class="box-body">
                        <div class="col-md-6">
                            

                               <div class="form-group">
                                    <label>Поставщик</label>
                                    <select class="form-control select2" style="width: 100%;" name="supplier_id">


                                        <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option 
                                            value="<?php echo e($item->id); ?>"
                                            <?php echo e($item->id == $sl->shop_id ? 'selected' : ''); ?>

                                            ><?php echo e($item->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
             

                                 <div class="form-group">
                                    <label for="exampleInputEmail1">Курс USD</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" onkeyup="this.value = this.value.replace (/[^0-9]+$/, '')" value="<?php echo e($sl->dollar_rate); ?>" name="dollar_rate" >
                                </div>

                                 <div class="form-group">
                                    <label for="exampleInputEmail1">USD $</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" onkeyup="this.value = this.value.replace (/[^0-9]+$/, '')" value="<?php echo e($sl->usd); ?>" name="usd" >
                                </div>


                                 <div class="form-group">
                                    <label for="exampleInputEmail1">Наличные</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" onkeyup="this.value = this.value.replace (/[^0-9]+$/, '')" value="<?php echo e($sl->cash); ?>" name="cash">
                                </div>


                                 <div class="form-group">
                                    <label for="exampleInputEmail1">Терминал</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" onkeyup="this.value = this.value.replace (/[^0-9]+$/, '')"  value="<?php echo e($sl->terminal); ?>"
                                    name="terminal" >
                                </div>


                        </div>
                    </div>






                    <!-- /.box-body -->
                    <div class="box-footer">
                        <input type="hidden" name="_method" value="put">
                        <button class="btn btn-default">Назад</button>
                        <button class="btn btn-warning pull-right" type="submit">Изменить</button>
                    </div>
                    <!-- /.box-footer-->
                </div>
            </form>
            <!-- /.box -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/admin/payments-supplier/edit.blade.php ENDPATH**/ ?>