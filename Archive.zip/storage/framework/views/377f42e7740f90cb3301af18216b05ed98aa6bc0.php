








<?php $__env->startSection('content'); ?>

<div class="reveal-overlay product-categories-wrap" style="/* display: block; */">
        <div class="swipe left swipe-menu reveal" id="catalogMenu" style="display: block;">
            <div class="swipe-menu-container">
                <div class="swipe-menu-header">
                    <div class="reveal-header">
                        <h4>Категории продуктов</h4> <button class="close-button" aria-label="Close modal"><span aria-hidden="true">×</span></button>
                    </div>
                </div>
                <div class="swipe-menu-body">
                    <div class="reveal-body">
                        <ul class="vertical dropdown menu" id="revealMenu">
                            <?php $__currentLoopData = $product_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li role="menuitem"> 
                                <a class="" aria-current="false" href="<?php echo e($item->slug); ?>">
                                    <img src="<?php echo e($item->getImage()); ?>" alt="" class="category-image"> <span><?php echo e($item->title); ?></span>
                                </a> 
                            </li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


   <main>
   	<section class="home-page">
            <div class="home-intro">
							<?php $__env->startSection('slider'); ?>
							    <?php echo $__env->make("lib.slider", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<?php $__env->stopSection(); ?>



<!-- categories -->
	                <section class="property">
                    <div class="container">
                        <div class="slick-categories">
                            <?php $__currentLoopData = $product_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item-slide"> 


                                <a href="<?php echo e(route('category',['slug'=>$cat->slug])); ?>">
                                    <img src="<?php echo e($cat->getImage()); ?>" alt="" />

                                    <p><?php echo e($cat->title); ?></p>
                                </a> 
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
                        </div>
                    </div>
                </section>


                <section class="products-container products-slider IS_BEST_OFFER_ProductCarousel show">
                    <div class="row">
                        <div class="small-12">
                            <h4 class="section-title"> Каталог лучших предложений <a class="button btn-all-link" aria-current="false" href="#"> Все
                                    <i class="fa fa-angle-right"></i>
                                </a> </h4>
                            <div>
                                <section class="products-container products-container-wrap">
                                    <div class="row small-up-2 medium-up-4 large-up-6" style="padding-left: 15px; padding-right: 15px">

                                         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                       
                                        <div class="column no-column-padding">
                                            <div class="product-item"> 
                                                <a class="clickable" aria-current="false" href="<?php echo e(route('detail',['slug'=>$val->slug])); ?>">
                                                    <?php if($val->label): ?>
                                                    <div class="label-container"> <span class="label sale alert inline"><?php echo e($val->label); ?> %</span> </div>
                                                    <?php endif; ?>
                                                    <div class="bottom">
                                                        <div class="product-image">
                                                            <img src="<?php echo e($val->getImage()); ?>" class="product-img square-180" />
                                                        </div>
                                                        <h4 class="product-title"><?php echo e($val->title); ?></h4>
                                                        <div class="product__price clearfix"> 
                                                            <strong> <?php echo e($val->price); ?> <span>сум. за</span> <span class="unit-text">1 шт</span> </strong> <span class="small__text hide">( 4 990 сум. за 1 шт )</span>
                                                    </div>
                                                    <div class="add-cart horizontal cart-44732 wide-box not-added"> <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"></span> В корзину </button> </div>
                                                </a> </div>
                                        </div>
                                    </div>


                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="products-container products-slider IS_BEST_OFFER_ProductCarousel show">
                    <div class="row">
                        <div class="small-12">
                            <h4 class="section-title">
                                Скидочные товары
                                <a class="button btn-all-link" aria-current="false" href="#">
                                    Все
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </h4>
                            <div>
                                <section class="products-container products-container-wrap">
                                    <div class="row small-up-2 medium-up-4 large-up-6" style="padding-left: 15px; padding-right: 15px">
                                         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                       
                                        <div class="column no-column-padding">
                                            <div class="product-item"> 
                                                <a class="clickable" aria-current="false" href="<?php echo e(route('detail',['slug'=>$val->slug])); ?>">
                                                    <?php if($val->label): ?>
                                                    <div class="label-container"> <span class="label sale alert inline"><?php echo e($val->label); ?> %</span> </div>
                                                    <?php endif; ?>
                                                    <div class="bottom">
                                                        <div class="product-image">
                                                            <img src="<?php echo e($val->getImage()); ?>" class="product-img square-180" />
                                                        </div>
                                                        <h4 class="product-title"><?php echo e($val->title); ?></h4>
                                                        <div class="product__price clearfix"> 
                                                            <strong> <?php echo e($val->price); ?> <span>сум. за</span> <span class="unit-text">1 шт</span> </strong> <span class="small__text hide">( 4 990 сум. за 1 шт )</span>
                                                    </div>
                                                    <div class="add-cart horizontal cart-44732 wide-box not-added"> <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"></span> В корзину </button> </div>
                                                </a> </div>
                                        </div>
                                    </div>


                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="products-container products-slider IS_BEST_OFFER_ProductCarousel show">
                    <div class="row">
                        <div class="small-12">
                            <h4 class="section-title"> Каталог лучших предложений <a class="button btn-all-link" aria-current="false" href="#"> Все
                                    <!-- --> <i class="fa fa-angle-right"></i>
                                </a> </h4>
                            <div>
                                <section class="products-container products-container-wrap">
                                    <div class="row small-up-2 medium-up-4 large-up-6" style="padding-left: 15px; padding-right: 15px">
                                         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                       
                                        <div class="column no-column-padding">
                                            <div class="product-item"> 
                                                <a class="clickable" aria-current="false" href="<?php echo e(route('detail',['slug'=>$val->slug])); ?>">
                                                    <?php if($val->label): ?>
                                                    <div class="label-container"> <span class="label sale alert inline"><?php echo e($val->label); ?> %</span> </div>
                                                    <?php endif; ?>
                                                    <div class="bottom">
                                                        <div class="product-image">
                                                            <img src="<?php echo e($val->getImage()); ?>" class="product-img square-180" />
                                                        </div>
                                                        <h4 class="product-title"><?php echo e($val->title); ?></h4>
                                                        <div class="product__price clearfix"> 
                                                            <strong> <?php echo e($val->price); ?> <span>сум. за</span> <span class="unit-text">1 шт</span> </strong> <span class="small__text hide">( 4 990 сум. за 1 шт )</span>
                                                    </div>
                                                    <div class="add-cart horizontal cart-44732 wide-box not-added"> <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"></span> В корзину </button> </div>
                                                </a> </div>
                                        </div>
                                    </div>


                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
            <!--home-intro-->
        </section>
    </main>



    <section class="index_advantages">
        <div id="advantage-blocks">
            <div class="row">
                <div class="col-md-3 col-6">
                    <div class="icon">
                        <picture>
                            <source srcset="/public/assets/img/track.svg" type="image/webp"><img src="/public/assets/img/track.svg" alt="">
                        </picture>
                    </div>
                    <div class="info">
                        <h6>Удобная доставка</h6>
                        <p>Бесплатная доставка при <br>заказе от 500 000 сум</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="icon">
                        <picture>
                            <source srcset="/public/assets/img/wallet.svg" type="image/webp"><img src="/public/assets/img/wallet.svg" alt="">
                        </picture>
                    </div>
                    <div class="info">
                        <h6>Оплата любым способом</h6>
                        <p>5 способов оплаты для <br>твоего удобства</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="icon">
                        <picture>
                            <source srcset="/public/assets/img/shield.svg" type="image/webp"><img src="/public/assets/img/shield.svg" alt="">
                        </picture>
                    </div>
                    <div class="info">
                        <h6>Качественное гарантийное <br>обслуживание</h6>
                        <p>Поможем с ремонтом товара</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="icon">
                        <picture>
                            <source srcset="/public/assets/img/gift.svg" type="image/webp"><img src="/public/assets/img/gift.svg" alt="">
                        </picture>
                    </div>
                    <div class="info">
                        <h6>Подарочные <br>сертификаты</h6>
                        <p>Поможем с ремонтом товара</p>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footerinput'); ?>
    <?php echo $__env->make("lib.footerinput", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/index/index.blade.php ENDPATH**/ ?>