

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Добавить продукт

            </h1>
        </section>

        <!-- Main content -->
        <section class="content">

            <?php echo $__env->make('admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form method="post" action="<?php echo e(route('post.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <!-- Default box -->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Добавляем продукт</h3>
                    </div>


                    <div class="bs-example bs-example-tabs">


                        <div class="box-body">
                            <div class="col-md-6">



                               <div class="form-group">
                                    <label for="exampleInputEmail1">Артикул</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="article" >
                                </div>

                                 <div class="form-group">
                                    <label for="exampleInputEmail1">Партия</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="batch" >
                                </div>

                                 <div class="form-group">
                                    <label for="exampleInputEmail1">Количество</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="qty" >
                                </div>



                                <div class="form-group">
                                    <label>Склад</label>
                                    <select class="form-control select2" style="width: 100%;" name="sklad">


                                        <?php $__currentLoopData = $warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Магазин</label>
                                    <select class="form-control select2" style="width: 100%;" name="shop_id">


                                        <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>


                                <div class="form-group">
                                    <label>Поставщик</label>
                                    <select class="form-control select2" style="width: 100%;" name="supplier">


                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>




                                 
                                    
                                    
                                    
                                






                            <div class="form-group">
                                <label for="exampleInputEmail1">Закупочная Цена</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="buy_price"  >
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Розничная Цена</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="price" >
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Скидка</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="label" >
                            </div>

                            <div class="form-group">
                                <label>
                                <input type="checkbox"  name="is_sample" value="1" >
                                Образец</label>
                            </div>


                            <div class="form-group">
                                
                                <label for="exampleInputFile">Картинка</label>
                                <input type="file" id="exampleInputFile" name="img">

                                <p class="help-block">png,jpeg,jpg размер 400x266</p>
                            </div>




                               <!--  <div class="form-group">
                                    <label for="exampleInputEmail1">Название</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="title">
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Артикл</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="article">
                                </div>

                                <div class="form-group">
                                    <label>Магазин</label>
                                    <select class="form-control select2" style="width: 100%;" name="shop_id">


                                        <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Пользователь</label>
                                    <select class="form-control select2" style="width: 100%;" name="user_id">


                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
 -->


                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Описание</label>
                                    <textarea name="anonce" id="editor" cols="30" rows="10" class="form-control" ></textarea>
                                </div>
                            </div>


                        </div>






                    </div>



                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button class="btn btn-default">Назад</button>
                        <button class="btn btn-success pull-right" type="submit">Добавить</button>
                    </div>
                    <!-- /.box-footer-->
                </div>

            </form>
            <!-- /.box -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/admin/post/create.blade.php ENDPATH**/ ?>