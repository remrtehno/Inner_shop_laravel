<div class="cabinet-menu">
                        <div class="">
                            <ul class="menu vertical no-bullet">
                                <li><span class="current icon profile">Мой профиль</span></li>
                                <li> <a class="icon orders" href="{{route('orders')}}">Заказы</a> </li>
                                <!-- <li> <a class="icon wishlist" href="cabinet-favorit.html"> Товары </a> </li> -->
                               <!--  <li> <a class="icon chart" href="cabinet-statistic.html"> Статистика </a> </li> -->
                                <li> <a class="icon chart" href="{{route('cart')}}"> Корзина </a> </li>
                            </ul>
                        </div>
                    </div>