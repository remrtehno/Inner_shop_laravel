<?php $__env->startSection('content'); ?>
<style>
.invalid-feedback-2 {
    display: block;
}
</style>
 <section class="registr shadow_bc">
    <form method="POST" action="<?php echo e(route('register')); ?>"  class="registr niked">
                        <?php echo csrf_field(); ?>

                <a href="<?php echo e(url('/')); ?>" class="logo_reg">

                            <img src="/public/uploads/logo/logo.png">

                </a>

                <h1>Добро пожаловать</h1>
                <p> Зарегистрируйтесь на сайте с помощью номером телефона или E-mail или через социальную сеть </p>

                <div class="form-group">
                    <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" class="form-control tel_uz" required autocomplete="name" autofocus placeholder="+998xx-xx-xx-xx">
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <span class="invalid-feedback-2" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group"> 
                    <input type="text" required name="email" class="form-control" value="" placeholder="Введите E-mail" />
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <span class="invalid-feedback-2" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                </div>
                <div class="form-group"> 
                    <input type="password" required name="password" class="form-control" placeholder="Пароль" value="" /> 
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback-2" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group ">

                    <div class="col-md-12" style="padding: 0;">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Подтвердите пароль" required autocomplete="new-password">
                    </div>
                </div>

                <div class="agree_ser"> 
                    <input type="checkbox" name="agree" id="ber" value="0" style="display: none" /> <label for="ber"> Я соглашаюсь с <a href="https://bisyor.uz/terms" target="_blank"> правилами использования сервиса </a> , а также с передачей и обработкой моих данных* </label> </div> <button type="submit" class="more_know blue"> Зарегистрироваться </button>
            </form>
            <div class="reg_bottom">
                <p>© 2018-2020 site - Все права защищены</p>
                <p> По вопросам: <a href="mailto:info@site.uz">info@site.uz</a> </p>
            </div>
        </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/bd/resources/views/auth/register.blade.php ENDPATH**/ ?>